USE Northwind;

SELECT * FROM dbo.Employees;

SELECT * FROM dbo.Employees;

SELECT e.EmployeeID, e.FirstName
FROM dbo.Employees e;

USE db01;
--Ctrl + Shift + R
SELECT c.cust_id, c.cust_name, c.mobile
FROM dbo.Customer c;


